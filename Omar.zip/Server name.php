$serverName = "127.0.0.1\\sql"; // استخدم \\ للهروب الصحيح
$connectionOptions = array(
    "Database" => "platform",
    "Uid" => "sa",
    "PWD" => "123123",
    "CharacterSet" => "UTF-8"
);